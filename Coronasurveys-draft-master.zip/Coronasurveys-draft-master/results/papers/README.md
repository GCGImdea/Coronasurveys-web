Papers and reports produced in the CoronaSurveys project
