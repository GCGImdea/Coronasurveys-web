
<iframe src="https://covid19.algolysis.com/grafana/d-solo/G_Aw4CrZk/coronasurveys?orgId=1&var-code=CL&var-country=Chile&from=1583350357211&to=1585942357211&panelId=10" width="650" height="600" frameborder="0"></iframe>

[Fill the Survey for Chile](https://tinyurl.com/coronasurveyschile)

