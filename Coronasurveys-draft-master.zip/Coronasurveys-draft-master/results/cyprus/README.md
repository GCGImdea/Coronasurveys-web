

<iframe src="https://covid19.algolysis.com/grafana/d-solo/G_Aw4CrZk/coronasurveys?orgId=1&from=1583934918142&var-code=CY&var-country=Cyprus&panelId=10" width="650" height="600" frameborder="0"></iframe>

[Fill the Survey for Cyprus](https://tinyurl.com/coronasurveyscyprus){: .btn}
